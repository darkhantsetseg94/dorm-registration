const express = require('express');
const { requireRole } = require('../middleware/auth');
const { validateApplication, parseId } = require('../validators/applicationValidator');
const { currentAcademicYear } = require('../utils/time');
const { AppError, invalid } = require('../errors');

function idFrom(req) {
  const id = parseId(req.params.id);
  if (!id) throw new AppError(400, 'Хүсэлтийн дугаар буруу байна');
  return id;
}

/** Оюутны хүсэлттэй холбоотой endpoint-ууд (нэвтэрсэн байхыг app.js шалгана) */
function createApplicationRouter(services) {
  const router = express.Router();
  const { applications, dorms, settings } = services;

  // Form-ын сонголтод зориулсан байрны жагсаалт (сул орны тоотой)
  router.get('/dormitories', (req, res) => {
    res.json({ dormitories: dorms.list(currentAcademicYear(), req.session.user) });
  });

  // Хүсэлт хүлээн авч буй эсэх
  router.get('/applications/window', (req, res) => {
    res.json({ window: settings.applicationWindow() });
  });

  // US-01: Дотуур байранд суух хүсэлт илгээх
  router.post('/applications', requireRole('student'), (req, res) => {
    const { errors, data } = validateApplication(req.body);
    if (errors) throw invalid(errors);
    const application = applications.create(req.session.user, data);
    res.status(201).json({ message: 'Хүсэлт амжилттай илгээгдлээ', application });
  });

  // Оюутны өөрийн илгээсэн хүсэлтүүд
  router.get('/applications/my', requireRole('student'), (req, res) => {
    const list = applications.listForStudent(req.session.user.id);
    const body = { applications: list, currentYear: currentAcademicYear() };
    if (list.length === 0) body.message = 'Илгээсэн хүсэлт байхгүй байна';
    res.json(body);
  });

  // Нэг хүсэлтийн дэлгэрэнгүй (эзэмшигч эсвэл ажилтан)
  router.get('/applications/:id', (req, res) => {
    res.json({ application: applications.getById(req.session.user, idFrom(req)) });
  });

  // Хүлээгдэж буй хүсэлтээ засах
  router.put('/applications/:id', requireRole('student'), (req, res) => {
    const id = idFrom(req);
    const { errors, data } = validateApplication(req.body);
    if (errors) throw invalid(errors);
    const application = applications.update(req.session.user, id, data);
    res.json({ message: 'Хүсэлтийг хадгаллаа', application });
  });

  // Хүлээгдэж буй хүсэлтээ цуцлах
  router.post('/applications/:id/cancel', requireRole('student'), (req, res) => {
    const application = applications.cancel(req.session.user, idFrom(req));
    res.json({ message: 'Хүсэлтийг цуцаллаа', application });
  });

  return router;
}

module.exports = { createApplicationRouter };
