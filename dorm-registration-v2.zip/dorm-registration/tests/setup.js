// Тест орчны тохиргоо (зөвхөн тестэд ашиглах утгууд)
process.env.NODE_ENV = 'test';
process.env.SESSION_SECRET = 'jest-only-session-secret';
